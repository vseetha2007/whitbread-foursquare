package com.whitbread.foursquare.integration.domain;

public abstract class AbstractModel {

}
